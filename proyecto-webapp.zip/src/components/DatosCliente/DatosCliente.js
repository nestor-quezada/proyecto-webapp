import React, { Component } from 'react';
import './DatosCliente.css';
import { Route, Link } from 'react-router-dom';

class DatosCliente extends Component {

    // constructor(props){
    //     super(props);
    // }
        
    render (){

      
        return (

            <div className="DatosCliente">
                
                <h1>Datos cliente</h1>

                <Link to="/" className="btn btn-primary">
                    {/* <button type="button" class="btn btn-primary">Cancelar</button> */}
                </Link>
                <button type="button" class="btn btn-primary">Realizar Pedido</button>

            </div>

            

        );

    }

}

export default DatosCliente;