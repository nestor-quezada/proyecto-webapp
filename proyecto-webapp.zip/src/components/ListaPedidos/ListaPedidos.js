import React, { Component } from 'react';
import './ListaPedidos.css';

class ListaPedidos extends Component {

    constructor(props){
        super(props);
    }
        
    render (){

      
        return (

            <div className="ListaPedidos">
                
               <h1>Lista de pedidos</h1>

            </div>

            

        );

    }

}

export default ListaPedidos;