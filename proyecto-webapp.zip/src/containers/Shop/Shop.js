import React, { Component } from 'react';

import axios from '../../axios';
import Home from '../../components/Home/Home';
import RealizarPedido from '../../components/RealizarPedido/RealizarPedido';
import ListaPedidos from '../../components/ListaPedidos/ListaPedidos';
import { Route, Link } from 'react-router-dom';


class Shop extends Component {

    

    render() {

        return (
            <div>
                <Link to="/">
                  <button type="button" class="btn btn-primary">Home</button>
                </Link>

                
                
                <Route path="/" exact component={Home} />
                <Route path="/lista-pedidos" exact component={ListaPedidos} />
                <Route path="/realizar-pedido" exact component={RealizarPedido} />
                
            </div>

        );

    }


}

export default Shop;